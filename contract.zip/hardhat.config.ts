import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const ALCHEMY_API_KEY = "QQZ_P2XOgtdU5y-JryWvYkxc5JFabXd0";
const YOUR_PRIVATE_KEY = "d6889aeedf8a790c8311a36d00b2986b4b5fc65d65f84a67ada265678580a137";

const config: HardhatUserConfig = {
  solidity: "0.8.17",
  networks: {
    goerli: {
      url: `https://eth-goerli.alchemyapi.io/v2/${ALCHEMY_API_KEY}`,
      chainId: 5,
      accounts: [YOUR_PRIVATE_KEY]
    },
    ethereum: {
      url: `https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161`,
      chainId: 1,
      accounts: [YOUR_PRIVATE_KEY]
    },
    avalancheTest: {
      url: 'https://api.avax-test.network/ext/bc/C/rpc',
      chainId: 43113,
      accounts: [YOUR_PRIVATE_KEY]
    },
    avalancheMain: {
      url: 'https://api.avax.network/ext/bc/C/rpc',
      chainId: 43114,
      accounts: [YOUR_PRIVATE_KEY]
    },
    polygonTest: {
      url: ' https://rpc-mumbai.maticvigil.com/',
      chainId: 80001,
      accounts: [YOUR_PRIVATE_KEY]
    },
    polygonMain: {
      url: 'https://polygon-rpc.com',
      chainId: 137,
      accounts: [YOUR_PRIVATE_KEY]
    }
  }
};

export default config;
